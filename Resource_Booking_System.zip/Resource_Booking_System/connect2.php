 <?php
  $Firstname=$_POST['Firstname'];
  $lastname=$_POST['lastname'];
  $gender=$_POST['gender'];
  $phone=$_POST['mobile'];
  $email=$_POST['email'];
  $address=$_POST['address'];
  $purpose=$_POST['purpose'];
  $date=$_POST['date'];
  $m_months=$_POST['m_months'];
  $y_years=$_POST['y_years'];
  $P_type=$_POST['type'];
  $owner=$_POST['NoC'];
  $CVV=$_POST['CVV'];
  $Card_No=$_POST['CNO'];
  $Exp_month=$_POST['months'];
  $Exp_yeay=$_POST['years'];
  
  //Database Connection 
  
  $conn=new mysqli('localhost','root','','payment');
  
  if($conn->connect_error){
	  
	  die('connection failed :'.$conn->connect_error);
	  
  }else{ 
	  
      	  
$stmt=$conn->prepare("insert into details(Firstname,lastname,gender,mobile,email,address,purpose,
date,m_months,y_years,type,NoC,CVV,CNO,months,years)values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");


 $stmt->bind_param("sssissssssssisss",$Firstname,$lastname,$gender,$phone,$email,$address,
 $purpose,$date,$m_months,$y_years,$P_type,$owner,$CVV,$Card_No,$Exp_month,$Exp_yeay);
      $stmt->execute();
      echo "Booking Successfull..";
      $stmt->close();
      $conn->close();	
  }
  
   
  ?>