<!DOCTYPE html>
<html>
<head>
<style>

}
			table{
				border-collapse: collapse;
				width:100%;
				color: red;
				font-size: 30px;
				text-align:left;
			}

			th{
				background-color: orange;
				color:yellow;
			}

			tr:nth-child(even){
				background-color:blue;
			}
            
        
		</style>	
</head>
<?php

$con = new PDO("mysql:host=localhost;dbname=club_house5",'root','');

if (isset($_POST["submit"])) {
	$str = $_POST["search"];
	$sth = $con->prepare("SELECT * FROM `resources` WHERE R_type = '$str'");

	$sth->setFetchMode(PDO:: FETCH_OBJ);
	$sth -> execute();

	if($row = $sth->fetch())
	{
		?>
		<br><br><br>
		<table>
			<tr>
				<th>R_type</th>
				<th>R_name</th>
				<th>NOS</th>
				<th>Fee</th>
			</tr>
			<tr>
				<td><?php echo $row->R_type; ?></td>
				<td><?php echo $row->R_name;?></td>
				<td><?php echo $row->NOS; ?></td>
				<td><?php echo $row->Fee;?></td>
			</tr>

		</table>
<?php 
	}
		
		
		else{
			echo "Name Does not exist";
		}


}

?>
</html>