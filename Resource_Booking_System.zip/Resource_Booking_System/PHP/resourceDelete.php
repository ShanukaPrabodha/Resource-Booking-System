<?php
//Linking the configuration file

//The connection object
$conn=new mysqli("localhost","root","","club_house6");
// Check connection
	if($conn->connect_error){
		die("Connection failed: " . $connss->connect_error);
	}
$ID = $_GET['id'];
$query = "delete from resources1 where RID = '$ID'";

$t_data = mysqli_query($conn,$query);

if($t_data){
    echo "<script>alert ('Record deleted successfully!')</script>";
    header ("location:Resources.php");
}
else{
    echo"<script>alert ('error in deleting')</script>";
}
mysqli_close($conn);

?>    