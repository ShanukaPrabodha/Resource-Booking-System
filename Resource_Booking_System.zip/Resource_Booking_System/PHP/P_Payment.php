<!DOCTYPE html>
<html>
	<head>
    <title>
    </title>
	<link rel="stylesheet" type="text/css" href="Admin_styles/inside.css">
       <div class="Pay_Head1">
<a href="#"><img align="left" src="images/logo1.jpg" width="110px"  height="110px" alt="Club house logo" class="Pay_logo1"></a>

</div>

<div class="Pay_name1">
<!-- add a header (c)-->
<h1 align="left">Club House Bookings</h1>
<!-- add a sub-header (c) -->
<h3 align="left" id="header1">make your own booking...</h3>

<hr class="Ai">

</div>	
		<style>
		 body{
			 color:white;
            background-image:url("images/conifers.jpg");  
            }
			
			table{
				
				width:100%;
				color: #004080;
				font-family: georgian;
				font-size: 25px;
				text-align:center;
				position:relative;
				top:20px;
				
			}

			th{
				background-color:#001a00;
				color:#e6f2ff;
			}

			tr:nth-child(even){
				background-color:#003300;
				color:#e6f2ff;
				
			}
			
			tr:nth-child(odd){
				
				background-color:#008000;
				color:#e6f2ff;
			}
			
			input{
				width:60px;
	            height:40px;
	            border:5px solid #134d00;
	            background-color:#66ff33;
	            font-weight:bold;
	            color:#0d3300;	
			}
		</style>	
	</head>
<body>
<table>
	<tr>
		<th>Payment_ID</th>
		<th>Resource_ID</th>
		<th>Booking_ID</th>
		<th>Amount</th>
		
    </tr>					
<?php
//Linking the configuration file

//The connection object
$conn=new mysqli("localhost","root","","club_house4");
// Check connection
	if($conn->connect_error){
		die("Connection failed: " . $conn->connect_error);
	}

$payment = "select PID,RID,BID,P_Amount from payment";
$result = $conn->query($payment);



	if($result->num_rows > 0){
		//read table data
		while($t_row = $result->fetch_assoc()){
		echo"
		<tr>
		    <td>".$t_row['PID']."</td>
			<td>".$t_row['RID']."</td>
			<td>".$t_row['BID']."</td>
			<td>".$t_row['P_Amount']."</td>
			
			
			<td><a href = 'paymentdelete.php?id=$t_row[PID]'>
			<input type='submit' value = 'Delete User'></a></td>
		</tr>";	
		
		}
	}
	else
	{
		echo "no User Data";
	}
$conn->close();
?>
</table>
</body>
</html>
