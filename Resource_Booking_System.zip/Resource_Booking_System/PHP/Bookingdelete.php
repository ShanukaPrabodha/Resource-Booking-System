<?php
//Linking the configuration file

//The connection object
$conn=new mysqli("localhost","root","","club_house3");
// Check connection
	if($conn->connect_error){
		die("Connection failed: " . $conn->connect_error);
	}
$ID = $_GET['id'];
$query = "delete from bookings2 where BID = '$ID'";

$t_data = mysqli_query($conn,$query);

if($t_data){
    echo "<script>alert ('Record deleted successfully!')</script>";
    header ("location:Bookings.php");
}
else{
    echo"<script>alert ('error in deleting')</script>";
}
mysqli_close($conn);

?>    