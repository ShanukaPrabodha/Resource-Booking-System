<?php
//Linking the configuration file

//The connection object
$conn=new mysqli("localhost","root","","club_house4");
// Check connection
	if($conn->connect_error){
		die("Connection failed: " . $con->connect_error);
	}
$ID = $_GET['id'];
$query = "delete from payment where PID = '$ID'";

$t_data = mysqli_query($conn,$query);

if($t_data){
    echo "<script>alert ('Record deleted successfully!')</script>";
    header ("location:P_Payment.php");
}
else{
    echo"<script>alert ('error in deleting')</script>";
}
mysqli_close($conn);

?>    