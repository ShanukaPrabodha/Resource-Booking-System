

function loadData(name){
	
	if (name=="btn1"){
		document.getElementById("para").innerHTML="The iPhone X used a glass and stainless-steel form factor and  design, shrinking the bezels while not having a , unlike many Android phones. It was the first iPhone to use an OLED screen. The home button's fingerprint sensor was replaced with a new type of authentication called Face ID, which used sensors to scan the user's face to unlock the device. This face-recognition capability also enabled emojis to be animated following the user's expression (Animoji). With a bezel-less design, iPhone user interaction changed significantly, using gestures to navigate the operating system rather than the home button used in all previous iPhones. At the time of its November 2017 launch, its price tag of US$999 also made it the most expensive iPhone ever, with even higher prices internationally due to additional local sales and import taxes. "
		document.getElementById("image1").src="images/x.jpg"
	}
	else if(name=="btn2"){
		document.getElementById("para").innerHTML="The iPhone XS and iPhone XS Max (stylized and marketed as iPhone Xs and iPhone Xs Max; Roman numeral  pronounced )[12][13] are smartphones designed, developed and marketed by Apple Inc. They are the twelfth-generation flagships of the iPhone, succeeding the iPhone X.[14] Apple CEO Tim Cook announced the devices alongside a lower-end model, the iPhone XR, on September 12, 2018, at the Steve Jobs Theater at Apple Park. Pre-orders began on September 14, 2018, and went on sale on September 21.[15]The XS Max was the first plus-sized iPhone to have the newer bezel-less form factor, as the iPhone X did not have a larger variant. The iPhone XS (and XS Max) was discontinued on September 10, 2019, after the announcement of the iPhone 11 and 11 Pro. On January 20, 2020, Apple started selling certified refurbished models starting at $699. "
		document.getElementById("image1").src="images/xsmax.jpg"
	}
	else if(name=="btn3"){
		document.getElementById("para").innerHTML="The iPhone 8 and iPhone 8 Plus are smartphones designed, developed, and marketed by Apple Inc. They make up the 11th generation of the iPhone, along with the iPhone X. They were released on September 22, 2017, succeeding iPhone 7 and iPhone 7 Plus.[8] The iPhone 8 and iPhone 8 Plus were discontinued by Apple on April 15, 2020 with the release of the second-generation iPhone SE.Except for addition of a glass back, the designs of iPhone 8 and 8 Plus are largely similar to that of their predecessors. Notable changes include the removal of the rose gold color variant,[9] addition of inductive charging, a faster processor, and improved cameras and displays. The iPhone 8 and 8 Plus share most of their internal hardware with the iPhone X. "
		document.getElementById("image1").src="images/8.jpg"
	}
	else if(name=="btn4"){
		document.getElementById("para").innerHTML="The second-generation iPhone SE (also known as the iPhone SE 2 or the iPhone SE 2020) is a smartphone designed and developed by Apple Inc. It is part of the 13th generation of the iPhone, alongside the iPhone 11 and 11 Pro/Pro Max models. Apple announced the second-generation iPhone SE on April 15, 2020 and discontinued the iPhone 8 series. The iPhone SE succeeded the smaller and lighter first-generation iPhone SE. Pre-orders began on April 17, 2020, and the phone was subsequently released on April 24, 2020.[10] It was released with a starting price of US$399, and positioned as a budget phone.[11][12]"
		document.getElementById("image1").src="images/se.jpg"
	}
	else{
		alert("invalid!!")
	}
	
	
}

function checkPassword(){
	
	if(document.getElementById("pwd").value!=document.getElementById("cnfrmpwd").value){
		alert ("password missmatch");
		return false;
		
	}
	else{
		
		alert ("password match");
		
		return true;
		
	}
}
	
function enableButton(submitBtn){
	
	if(document.getElementById("checkbox").checked){
		
		document.getElementById("submitBtn").disabled=false;
		
	}
	else{
		
		document.getElementById("submitBtn").disabled=true;
	}
	
}
	
	
	
	
	






/*function priceForLoop(){

var phone=["IPhone X = Rs 15000/=","Apple iPhone XS Max = Rs 25000/=","iPhone 8 plus = Rs 10000/=","IPhone SE = Rs 5000/="];

for(i = 0, len = phone.length, list="List of Average Prices (using For Loop) <br/>"; i < len; i++){

      list += phone[i] + "<br/>";
	
}

document.getElementById("para").innerHTML=list;
document.getElementById("image1").src="images/phones.png";

}*/

function priceForInLoop(){
	var phone = [];
	phone["IPhone X"] = "Rs 15000/=";
	phone["IPhone XS MAX"] = "Rs 25000/=";
	phone["iPhone 8"] = "Rs 10000/="; 
	phone["IPhone SE"] = "Rs 5000/=";
	
		
	var list="List of Average Prices (using For In Loop)<br/>";
	for(var item in phone) {
		list += item + " : " + phone[item] + "<br />";
	}
	document.getElementById("image1").src="images/phones.png";
	document.getElementById("para").innerHTML = list;
}


function priceHigher(){
	
	var phone=[];
	
	phone["IPhone X"]= 15000;
	phone["IPhone XS MAX"]= 25000;
	phone["IPhone 8"]= 10000;
	phone["IPhone SE"]= 5000;
	
	var HighPrice = "List of high cost mobile phones <br/>";
	
	for(var item in phone){
		
		if(phone[item] >12000)
		{
			HighPrice += item + " : " + phone[item] + "<br />";
		}
		
	}
	
	document.getElementById("image1").src="images/phones.png";
	document.getElementById("para").innerHTML = HighPrice;
	
	
}

function priceLower(){
	
	var phone=[];
	
	phone["IPhone X"]= 15000;
	phone["IPhone XS MAX"]= 25000;
	phone["IPhone 8"]= 10000;
	phone["IPhone SE"]= 5000;
	
	var LowPrice = "List of high cost mobile phones <br/>";
	
	for(var item in phone){
		
		if(phone[item] <12000)
		{
			LowPrice += item + " : " + phone[item] + "<br />";
		}
		
	}
	
	document.getElementById("image1").src="images/phones.png";
	document.getElementById("para").innerHTML = LowPrice;
	
	
}



























