 <?php
  $Firstname=$_POST['Firstname'];
  $lastname=$_POST['lastname'];
  $gender=$_POST['gender'];
  $email=$_POST['email'];
  $password=$_POST['password'];
  
  
  //Database Connection 
  
  $conn=new mysqli('localhost','root','','shanuka');
  
  if($conn->connect_error){
	  
	  die('connection failed :'.$conn->connect_error);
	  
  }else{ 
	  
	  $stmt=$conn->prepare("insert into shanuka(Firstname,lastname,gender,email,password) values(?,?,?,?,?)");
	  $stmt->bind_param("sssss",$Firstname,$lastname,$gender,$email,$password);
      $stmt->execute();
echo"registration Successfully...";	 
      $stmt->close();
	  $conn->close(); 
      	  
  }
  
   
  
 
 ?>